
package kz.iitu.eventregistration.service;

import kz.iitu.eventregistration.model.EventInfo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {

    private final List<EventInfo> events = List.of(
            new EventInfo(1, "Web Design Workshop", "Astana"),
            new EventInfo(2, "JavaScript Quiz", "Online"),
            new EventInfo(3, "IT Career Talk", "Astana")
    );

    public String getWelcomeMessage() {
        return "Welcome to the Event Registration API";
    }

    public List<EventInfo> getAllEvents() {
        return events;
    }
}
