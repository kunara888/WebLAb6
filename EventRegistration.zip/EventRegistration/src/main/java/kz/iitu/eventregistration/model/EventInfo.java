
package kz.iitu.eventregistration.model;

public record EventInfo(
        int id,
        String title,
        String location
) {
}
